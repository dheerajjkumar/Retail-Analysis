select fe.product_code,dm.product_name,fe.promo_type,fe.base_price
from fact_events fe
join dim_products dm
on fe.product_code=dm.product_code
where base_price > 500 and 
promo_type = "BOGOF"
order by base_price;

SELECT * FROM retail_events_db.dim_stores;
SELECT city, COUNT(*) AS store_count
FROM dim_stores
GROUP BY city
ORDER BY store_count DESC;

with cte as
(select campaign_name,base_price,quantity_sold_before_promo,quantity_sold_after_promo,
round((quantity_sold_before_promo*base_price)/1000000,2)as revenue_before_promo,
round((quantity_sold_after_promo*base_price)/1000000,2) as revenue_after_promo
from fact_events fe
join dim_campaigns dc
on fe.campaign_id=dc.campaign_id)

select campaign_name,sum(revenue_before_promo) as revenue_befpromo_M,
sum(revenue_after_promo) revenue_aftpromo_M
from cte
group by campaign_name;
with cte as
(select campaign_name,base_price,revenue_before_promo,revenue_after_promo
from fact_events_revenue fe
join dim_campaigns dc
on fe.campaign_id=dc.campaign_id)

select campaign_name,round(sum(revenue_before_promo)/1000000,2) as revenue_befpromo_M,
round(sum(revenue_after_promo)/1000000,2) revenue_aftpromo_M
from cte
group by campaign_name;

SELECT 
    category,SUM(quantity_sold_after_promo),SUM(quantity_sold_before_promo),
    ((SUM(quantity_sold_after_promo) - SUM(quantity_sold_before_promo)) / SUM(quantity_sold_before_promo)) * 100 AS isu_percentage,
RANK() OVER (ORDER BY ((SUM(quantity_sold_after_promo) - SUM(quantity_sold_before_promo)) / SUM(quantity_sold_before_promo))  DESC) AS rank_order
FROM 
 fact_events fe
join dim_campaigns dc
on fe.campaign_id=dc.campaign_id
join  dim_products dp
on fe.product_code=dp.product_code

WHERE 
    campaign_name = 'Diwali'
GROUP BY 
     category
ORDER BY 
    isu_percentage DESC;

SELECT * FROM retail_events_db.fact_events_revenue;

with cte as
(select campaign_name,base_price,revenue_before_promo,revenue_after_promo
from fact_events_revenue fe
join dim_campaigns dc
on fe.campaign_id=dc.campaign_id)

select campaign_name,round(sum(revenue_before_promo)/1000000,2) as revenue_befpromo_M,
round(sum(revenue_after_promo)/1000000,2) revenue_aftpromo_M
from cte
group by campaign_name;
SELECT
    product_name,
    category,
    (SUM(revenue_after_promo) - SUM(revenue_before_promo)) / SUM(revenue_before_promo)*100 AS ir_percentage
FROM
    fact_events_revenue fev
    join dim_products dm
    on fev.product_code=dm.product_code
GROUP BY
    product_name, category
ORDER BY
    ir_percentage DESC
LIMIT 5;